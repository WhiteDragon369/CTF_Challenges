from django.shortcuts import render
from django.http import JsonResponse

def add(a,b):
    return a + b

def sub(a,b):
    return a - b

def mul(a,b):
    return a * b

def divide(a,b):
    return a / b

def getFlag(a,b):
    if a == 1337 and b == 7331:
        return "FLAG"
    else:
        return "NO FLAG"

def calculate(request):
    if request.method == 'POST':

        received = request.body.decode().split('"')
        received = {received[1]: received[-2]}
        expression = received.get('expression')

        result = "Error Occured"

        if '+' in expression:
            expression = expression.split('+')
            result = add(int(expression[0]), int(expression[1]))
        elif '-' in expression:
            expression = expression.split('-')
            result = sub(int(expression[0]), int(expression[1]))
        elif '*' in expression:
            expression = expression.split('*')
            result = mul(int(expression[0]), int(expression[1]))
        elif '/' in expression:
            expression = expression.split('/')
            result = divide(int(expression[0]), int(expression[1]))
        elif '=' in expression:
            if ';' not in expression and 'import' not in expression and ' ' not in expression:
                expression = expression.split('=')
                exec(expression[0] + '=' + expression[1])
            result = "Value set"

        if len(expression) != 2:
            result = "Error Occured"

        data = {"result": result}
        return JsonResponse(data)
    return render(request, 'index.html')


